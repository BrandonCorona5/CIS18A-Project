package salonpackage;

public interface Service {
    public double getCost();

    public void setCost(double cost);

    public String getName();

    public void setName(String name);
}